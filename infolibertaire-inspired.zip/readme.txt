InfoLibertaire Inspired
=======================

Thème WordPress inspiré d'InfoLibertaire.net.

Copyright (C) 2025 AnARCHIS12
Distribué sous licence GPL v2 ou ultérieure.

Pour toute question, voir le fichier style.css ou le dépôt GitHub.
